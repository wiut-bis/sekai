const express = require('express')
const path = require('path')
const fs = require('fs')

const app = express()
const bodyParser = require('body-parser')
const PORT = 5000 || process.env.PORT

app.use('/static', express.static(path.join(__dirname, 'public')))
app.use(bodyParser.urlencoded({ extended: false }))

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'templates/index.html'))
})

app.post('/submit-idea', (req, res) => {  
  const idea = {
    name: req.body.name,
    email: req.body.email,
    description: req.body.description
  }

  fs.readFile(path.join(__dirname, '/data/db.json'), (error, data) => {
    if (error) throw error
    const ideas = JSON.parse(data)
    ideas.push(idea)

    fs.writeFile(path.join(__dirname, '/data/db.json'), JSON.stringify(ideas), (error) => {
      if (error) throw error
      res.sendFile(path.join(__dirname, 'templates/submit-idea.html'))
    })
  })
})

app.get('/ideas', (req, res) => {
  res.sendFile(path.join(__dirname, 'templates/idea-list.html'))
})

app.get('/api/idea-list', (req, res) => {
  fs.readFile(path.join(__dirname, '/data/db.json'), (error, data) => {
    if (error) throw error
    const response = JSON.parse(data)
    res.json(response)
  })
})

// run server
app.listen(PORT, (error) => {
  if(error) throw error
  console.log(`HTTP server is running on port http://localhost:${ PORT }`)
})