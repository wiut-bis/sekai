const oneLinerJoke = require('one-liner-joke')
const excludeTags = ['racist', 'dirty', 'sex', 'women']

const randomJoke = oneLinerJoke.getRandomJokeWithTag('life', { 
  'exclude_tags': excludeTags 
})

console.log(randomJoke.body)


// setInterval(() => {
//   const randomJoke = oneLinerJoke.getRandomJokeWithTag('life', { 
//     'exclude_tags': excludeTags 
//   })
//   console.log(randomJoke.body)
// }, 5000)



