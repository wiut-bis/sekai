// core libs
const path = require('path')
const fs = require('fs')

// local libs
const uniqueID = require('./utils')

// third party libs
const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const multer = require('multer')

const storageConfig = multer.diskStorage({
  destination: (req, file, cb) =>{
      cb(null, path.join(__dirname, 'public/uploads'));
  },
  filename: (req, file, cb) =>{
      cb(null, uniqueID() + '.jpg');
  }
});

//server config
const PORT = process.env.PORT || 5000
const dbRoot = path.join(__dirname, 'data/students.js')

// middlewares
app.use(bodyParser.urlencoded({ extended: false }))
app.use('/static', express.static(path.join(__dirname, 'public')))
app.use(multer({ storage:storageConfig }).single("photo"));

//setting template/view engine.
app.set('view engine', 'pug')

// url handlers 
app.get('/', (req, res) => {
  res.render('home', { title: 'Home' })
})

app.get('/students', (req, res) => {
  fs.readFile(dbRoot, (err, data) => {
    if (err) res.sendStatus(500)
    
    const students = JSON.parse(data)
    res.render('students', { title: 'Students', students: students })
  })
})

app.get('/students/:id', (req, res) => {
  const id = req.params.id
  
  fs.readFile(dbRoot, (err, data) => {
    if (err) res.sendStatus(500)
    
    const students = JSON.parse(data)

    const student = students.filter(student => student.id = id)[0]

    res.render('student-detail', { student: student })
  })
})

app.route('/add-student')
  .get((req, res) => {
    res.render('add-student', { title: 'Add student'})
  })
  .post((req, res) => {
    if (req.body != undefined) {
      fs.readFile(dbRoot, (err, data) => {
        if (err) res.sendStatus(500)
        const students = JSON.parse(data)

        students.push({
          id: uniqueID(),
          name: req.body.full_name,
          bio: req.body.bio,
          photo: req.file.filename
        })

        fs.writeFile(dbRoot, JSON.stringify(students), (err) => {
          if (err) res.sendStatus(500)

          res.render('add-student', { success: true })
        })
      })
    }
  })

app.get('/about', (req, res) => {
  res.render('about', { title: 'About' })
})

// run server
app.listen(PORT, (err) => {
  if (err) throw err

  console.log(`Server is up and running on http://localhost:${ PORT }`)
})