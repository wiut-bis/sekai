# Express based super basis web application

### Install dependencies
```shell
npm install express body-parser multer
```
 
### Run app
```shell
npm run dev
``` 