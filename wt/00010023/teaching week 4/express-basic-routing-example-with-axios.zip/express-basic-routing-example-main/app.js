// core lib
const path = require('path')
const fs = require('fs')

// third party lib
const express = require('express')
const bodyParser = require('body-parser')
const axios = require('axios')

const app = express()
const PORT = process.env.PORT || 5000

// local lib
const users = require('./routes/users')
const uid = require('./configs').uid
const dbPath = require('./configs').dbPath
const API = require('./configs').API
const { equal } = require('assert')

app.set('view engine', 'pug')

// middlewares
app.use(bodyParser.urlencoded({ extended: false }))
app.use('/static', express.static(path.join(__dirname, 'public')))
app.use('/users', users)

// url handler ty
app.get('/', (req, res) => {
  res.render('home', { title: 'Homepage' })
})

app.route('/tasks')
  // get request handler
  .get((req, res) => {
    axios.get(`${ API }/users`)
      .then(response => {
        res.render('tasks', { users: response.data })
      })
      .catch(err => res.sendStatus(500)) 
  })

  // post request handler
  .post((req, res) => {
    fs.readFile(dbPath('tasks'), (err, data) => {
      if (err) res.render('tasks', { success: false })
      
      const tasks = JSON.parse(data)
      
      tasks.push({
        uid: uid(),
        title: req.body.title,
        deadline: req.body.deadline,
        assigned: req.body.assigned 
      })

      fs.writeFile(dbPath('tasks'), JSON.stringify(tasks), (err) => {
        if (err) res.render('tasks', { success: false })
        
        res.redirect('/')
      })  
    })
  })


app.listen(PORT, (err) => {
  if (err) throw err
  console.log(`Server is running in port ${ PORT }`)
})