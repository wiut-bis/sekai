const path = require('path')

module.exports.uid = function () {
  return '_' + Math.random().toString(36).substr(2, 9);
}

module.exports.dbPath = function (collection) {
  return path.join(__dirname, `data/${ collection }.json`)
}

module.exports.API = 'https://jsonplaceholder.typicode.com'