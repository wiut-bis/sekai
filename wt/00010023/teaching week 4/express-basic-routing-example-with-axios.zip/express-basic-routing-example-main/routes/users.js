const fs = require('fs')
const express = require('express')
const axios = require('axios')

const router = express.Router()
const API = require('../configs').API
const dbPath = require('../configs').dbPath

router.get('/', (req, res) => {
  axios.get(`${ API }/users`)
    .then(response => {
      res.render('users', { users: response.data })
    })
    .catch(err => {
      res.sendStatus(500)
    })
})

router.get('/:id', (req, res) => {
  const id = req.params.id

  fs.readFile(dbPath('tasks'), (err, data) => {
    if (err) res.sendStatus(500)

    const tasks = JSON.parse(data)
    const taskList = tasks.filter(task => task.assigned === id)
    axios.get(`${ API }/users/${ id }`)
      .then(response => {
        res.render('user', { user: response.data, title: response.data.name, tasks: taskList})
      })
      .catch(err => {
        res.sendStatus(500)
      })
  })
})



module.exports = router