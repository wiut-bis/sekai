const express = require('express')
const router = express.Router()

router.get('/', (req, res) => {
  res.send('Tutors page...')
})

router.get('/:name', (req, res) => {
  res.send(`You are viewing ${ req.params.name }'s page...`)
})

module.exports = router
