const path = require('path')

const express = require('express')
const app = express()

const tutors = require('./routes/tutors.js')
app.use('/tutors', tutors)

app.get('/', (req, res) => {
  res.send('Hello Routing!')
})

// app.all example
app.all('/students', (req, res, next) => {
  console.log(`${ req.method } : ${ req.url }`)
  next()
})

// app.route example
app.route('/students')
  .get((req, res) => {
    res.sendFile(getView('students'))
  })
  .post((req, res) => {
    res.send('Post request...')
  })

app.listen(5000, (err ) => { 
  if (err) throw err 
  console.log('Running on port 5000...')
})


function getView (view) {
  return path.join(__dirname, `views/${ view }.html`)
}
